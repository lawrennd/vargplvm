function [Psi2, P] = whiteVardistPsi2Compute(whitekern, vardist, Z)

% WHITEVARDISTPSI2COMPUTE one line description
%
%	Description:
%
%	[PSI2, P] = WHITEVARDISTPSI2COMPUTE(WHITEKERN, VARDIST, Z)
%	description
%	 Returns:
%	  PSI2 - description
%	  P - description
%	 Arguments:
%	  WHITEKERN - the kernel structure associated with the white kernel.
%	  VARDIST - description
%	  Z - description
%	
%	
%	
%	
%
%	See also
%	OTHERS


%	Copyright (c) 2009 Michalis K. Titsias
% 	whiteVardistPsi2Compute.m SVN version 583
% 	last update 2009-11-08T13:07:35.000000Z

Psi2 = zeros(size(Z,1),size(Z,1)); 

P = [];




