function [K, Knovar, argExp] = rbfardjitVardistPsi1Compute(rbfardKern, vardist, Z)

% RBFARDJITVARDISTPSI1COMPUTE description.
%
%	Description:
%	[K, Knovar, argExp] = rbfardjitVardistPsi1Compute(rbfardKern, vardist, Z)
%% 	rbfardjitVardistPsi1Compute.m SVN version 1460
% 	last update 2011-07-04T19:08:51.534562Z


 [K, Knovar, argExp] = rbfard2VardistPsi1Compute(rbfardKern, vardist, Z);


