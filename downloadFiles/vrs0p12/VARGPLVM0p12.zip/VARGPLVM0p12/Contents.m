% VARGPLVM toolbox
% Version 0.12		07-Feb-2011
% Copyright (c) 2011, Neil D. Lawrence
% 
, Neil D. Lawrence
% VARGPLVMUPDATESTATS Update stats of VARGPLVM model.
% VARGPLVMREDUCEMODEL prunes out dimensions of the model.
% BIASVARDISTPSI0COMPUTE one line description
% VARGPLVMTOOLBOXES Load in the relevant toolboxes for variational gplvm.
% VARGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% LINARD2VARDISTPSI1COMPUTE description.
% VARGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% KERNVARDISTTEST description.
% VARGPLVMOPTIMISE Optimise the VARGPLVM.
% KERNVARDISTPSI0GRADIENT description.  
% KERNVARDISTPSI1COMPUTE description.  
% KERNKERNVARDISTPSI2COMPUTE description.
% WHITEVARDISTPSI0GRADIENT one line description
% KERNVARDISTPSI2GRADIENT description.  
% VARGPLVMOBJECTIVE Wrapper function for variational GP-LVM objective.
% LINARD2VARDISTPSI0GRADIENT description.
% RBFARD2VARDISTPSI0COMPUTE description.
% DEMOIL100POINT Description
% DEMROBOTWIRELESSVARGPLVM1 Run variational GPLVM on robot wireless data.
% RBFARD2BIASVARDISTPSI2COMPUTE description.
% DEMOILVARGPLVM2 Run variational GPLVM on oil data.
% RBFARD2VARDISTPSI2COMPUTE one line description
% RBFARD2VARDISTPSI0GRADIENT Description
% DEMBRENDANFGPLVM9 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 30 latent dimensions
% VARGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% VARGPLVMEXTRACTPARAM Extract a parameter vector from a variational GP-LVM model.
% LINARDVARDISTPSI1COMPUTE description.
% VARGPLVMPROBABILITYCOMPUTE description
% DEMBRENDANFGPLVM8 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 10 latent dimensions
% BIASVARDISTPSI0GRADIENT one line description
% VARGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% WHITEVARDISTPSI1COMPUTE one line description
% VARDISTEXPANDPARAM Expand a parameter vector into a vardist structure.
% VARGPLVMOBJECTIVEGRADIENT Wrapper function for VARGPLVM objective and gradient.
% DEMUSPSVARGPLVM1 Demonstrate variational GPLVM on USPS data. 
% WHITEVARDISTPSI2COMPUTE one line description
% KERNVARDISTPSI2COMPUTE description.  
% BIASVARDISTPSI2GRADIENT Compute gradient of bias variational PSI2.
% WHITEVARDISTPSI1GRADIENT Compute gradient of white variational Psi1.
% RBFARD2LINARD2VARDISTPSI2GRADIENT description
% KERNKERNVARDISTPSI2GRADIENT Description
% LINARD2BIASVARDISTPSI2COMPUTE one line description
% KERNKUUXUGRADIENT Description
% VARGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% WHITEVARDISTPSI2GRADIENT Compute gradient of white variational PSI2.
% RBFARD2LINARD2VARDISTPSI2COMPUTE description
% VARGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% VARGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% LINARDVARDISTPSI1GRADIENT description.
% VARGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% BIASVARDISTPSI1COMPUTE one line description
% DEMSWISSROLLVARGPLVM1 Run variational GPLVM on swiss roll data.
% DEMUSPSVARGPLVM2 Demonstrate linear variational GPLVM (Bayesian PCA) on USPS data.
% BIASVARDISTPSI2COMPUTE one line description
% KERNVARDISTPSI0COMPUTE description.  
% DEMBRENDANVARGPLVM1 Run variational GPLVM on Brendan face data.
% VARGPLVMOPTIONS Return default options for VARGPLVM model.
% LINARD2VARDISTPSI2COMPUTE description.
% VARDISTEXTRACTPARAM Extract a parameter vector from a vardist structure.
% DEMOVARGPLVM1 Description ...
% KERNVARDISTPSI1GRADIENT description.  
% RBFARD2VARDISTPSI1GRADIENT description.
% VARGPLVMLOGLIKEGRADIENTS Compute the gradients for the variational GPLVM.
% DEMOIL100VARGPLVM1 Run variational GPLVM on 100 points from the oil data.
% RBFARD2BIASVARDISTPSI2GRADIENT description.
% RBFARDVARDISTPSI1COMPUTE one line description
% VARGPLVMLOGLIKELIHOOD Log-likelihood for a variational GP-LVM.
% RBFARDVARDISTPSI2COMPUTE one line description
% RBFARDVARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI0COMPUTE Description
% RBFARD2VARDISTPSI2GRADIENT description.
% RBFARD2VARDISTPSI1COMPUTE description.
% VARGPLVMPOSTERIORVAR variances of the posterior at points given by X.
% DEMBRENDANVARGPLVM3 Run variational GPLVM on Brendan face data.
% KERNKERNVARDISTTEST Description
% LINARD2VARDISTPSI2GRADIENT description.
% VARDISTCREATE description.
% LINARD2VARDISTPSI1GRADIENT description.
% WHITEVARDISTPSI0COMPUTE one line description
% DEMBRENDANFGPLVM6 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 2 latent dimensions
% DEMBRENDANFGPLVM7 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 5 latent dimensions
% BIASVARDISTPSI1GRADIENT Compute gradient of bias variational PSI1.
% VARGPLVMPARAMINIT Initialize the variational GPLVM from the data
% VARGPLVMCREATE Create a GPLVM model with inducing variables.
% DEMBRENDANVARGPLVM2 Run variational GPLVM on Brendan face data.
% DEMOILVARGPLVM1 Run variational GPLVM on oil data.
% LINARD2BIASVARDISTPSI2GRADIENT description.
% VARGPLVMGRADIENT Variational GP-LVM gradient wrapper.
