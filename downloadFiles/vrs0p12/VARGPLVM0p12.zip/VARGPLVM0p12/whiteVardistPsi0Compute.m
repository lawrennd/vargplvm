function Psi0 = whiteVardistPsi0Compute(whitekern, vardist)

% WHITEVARDISTPSI0COMPUTE one line description
%
%	Description:
%
%	PSI0 = WHITEVARDISTPSI0COMPUTE(WHITEKERN, VARDIST) description
%	 Returns:
%	  PSI0 - description
%	 Arguments:
%	  WHITEKERN - the kernel structure associated with the white kernel.
%	  VARDIST - description
%	
%	
%	
%	
%
%	See also
%	OTHERS


%	Copyright (c) 2009 Michalis K. Titsias
% 	whiteVardistPsi0Compute.m SVN version 583
% 	last update 2009-11-08T13:07:35.000000Z

% the "white" kernel only affects the K_uu matrix (jitter inducing variables)"
% that's why the psi0_white = 0 
Psi0 = 0; % vardist.numData*whitekern.variance; 
%Psi0 =  vardist.numData*whitekern.variance;
