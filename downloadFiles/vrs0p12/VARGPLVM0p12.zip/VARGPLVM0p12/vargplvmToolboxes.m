
% VARGPLVMTOOLBOXES Load in the relevant toolboxes for variational gplvm.
%
%	Description:
%	% 	vargplvmToolboxes.m SVN version 584
% 	last update 2009-11-08T13:07:35.000000Z
importLatest('netlab');
importLatest('prior');
importLatest('optimi');
importLatest('datasets');
importLatest('mltools');
importLatest('kern');
importLatest('ndlutil');
importLatest('mocap');
importLatest('gp');