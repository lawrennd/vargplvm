function k0 = rbfard2VardistPsi0Compute(rbfardKern, vardist)

% RBFARD2VARDISTPSI0COMPUTE description.
%
%	Description:
%	k0 = rbfard2VardistPsi0Compute(rbfardKern, vardist)
%% 	rbfard2VardistPsi0Compute.m SVN version 583
% 	last update 2009-11-08T13:07:34.000000Z
  
% variational means

k0 = vardist.numData*rbfardKern.variance; 


