function [gKern, gVarmeans, gVarcovars] = rbfard2VardistPsi0Gradient(rbfard2Kern, vardist, covGrad)

% RBFARD2VARDISTPSI0GRADIENT Description
%
%	Description:
%	[gKern, gVarmeans, gVarcovars] = rbfard2VardistPsi0Gradient(rbfard2Kern, vardist, covGrad)
%% 	rbfard2VardistPsi0Gradient.m SVN version 583
% 	last update 2009-11-08T13:07:34.000000Z
gKern = zeros(1,rbfard2Kern.nParams); 
gKern(1) = covGrad*vardist.numData;
 
gVarmeans = zeros(1,prod(size(vardist.means))); 
gVarcovars = zeros(1,prod(size(vardist.means))); 




