% VARGPLVM toolbox
% Version 0.1		25-Oct-2010
% Copyright (c) 2010, Neil D. Lawrence
% 
, Neil D. Lawrence
% RBFARD2VARDISTPSI2GRADIENT description.
% WHITEVARDISTPSI1COMPUTE one line description
% DEMSWISSROLLVARGPLVM1 Run variational GPLVM on swiss roll data.
% LINARD2VARDISTPSI2GRADIENT description.
% BIASVARDISTPSI1COMPUTE one line description
% VARGPLVMCREATE Create a GPLVM model with inducing variables.
% LINARD2VARDISTPSI1COMPUTE description.
% VARDISTCREATE description.
% VARGPLVMUPDATESTATS Update stats of VARGPLVM model.
% DEMOIL100VARGPLVM1 Run variational GPLVM on 100 points from the oil data.
% VARGPLVMTOOLBOXES Load in the relevant toolboxes for variational gplvm.
% DEMBRENDANVARGPLVM1 Run variational GPLVM on Brendan face data.
% DEMUSPSVARGPLVM1 Demonstrate variational GPLVM on USPS data. 
% KERNVARDISTPSI1GRADIENT description.  
% BIASVARDISTPSI2COMPUTE one line description
% WHITEVARDISTPSI0GRADIENT one line description
% VARGPLVMEXTRACTPARAM Extract a parameter vector from a variational GP-LVM model.
% LINARD2VARDISTPSI2COMPUTE description.
% VARGPLVMLOGLIKEGRADIENTS Compute the gradients for the variational GPLVM.
% DEMBRENDANFGPLVM8 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 10 latent dimensions
% WHITEVARDISTPSI2GRADIENT Compute gradient of white variational PSI2.
% KERNVARDISTTEST description.
% BIASVARDISTPSI0COMPUTE one line description
% KERNVARDISTPSI2COMPUTE description.  
% WHITEVARDISTPSI1GRADIENT Compute gradient of white variational Psi1.
% RBFARD2VARDISTPSI2COMPUTE one line description
% KERNVARDISTPSI0COMPUTE description.  
% RBFARD2VARDISTPSI0COMPUTE description.
% DEMBRENDANVARGPLVM3 Run variational GPLVM on Brendan face data.
% VARGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% DEMBRENDANFGPLVM9 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 30 latent dimensions
% DEMOILVARGPLVM2 Run variational GPLVM on oil data.
% RBFARD2BIASVARDISTPSI2GRADIENT description.
% VARGPLVMPOSTERIORVAR variances of the posterior at points given by X.
% DEMROBOTWIRELESSVARGPLVM1 Run variational GPLVM on robot wireless data.
% RBFARD2VARDISTPSI0GRADIENT Description
% DEMOILVARGPLVM1 Run variational GPLVM on oil data.
% BIASVARDISTPSI2GRADIENT Compute gradient of bias variational PSI2.
% VARGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% KERNKUUXUGRADIENT Description
% VARGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% LINARD2BIASVARDISTPSI2GRADIENT description.
% VARGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% RBFARD2LINARD2VARDISTPSI2GRADIENT description
% VARGPLVMREDUCEMODEL prunes out dimensions of the model.
% DEMUSPSVARGPLVM2 Demonstrate linear variational GPLVM (Bayesian PCA) on USPS data.
% RBFARDVARDISTPSI1COMPUTE one line description
% VARGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% WHITEVARDISTPSI2COMPUTE one line description
% LVMLOADDATA Load a latent variable model dataset.
% KERNKERNVARDISTPSI2GRADIENT Description
% RBFARD2BIASVARDISTPSI2COMPUTE description.
% DEMBRENDANFGPLVM6 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 2 latent dimensions
% KERNVARDISTPSI0GRADIENT description.  
% VARDISTEXTRACTPARAM Extract a parameter vector from a vardist structure.
% DEMOVARGPLVM1 Description ...
% BIASVARDISTPSI1GRADIENT Compute gradient of bias variational PSI1.
% KERNKERNVARDISTTEST Description
% VARGPLVMPROBABILITYCOMPUTE description
% VARGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% VARDISTEXPANDPARAM Expand a parameter vector into a vardist structure.
% VARGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% LINARD2BIASVARDISTPSI2COMPUTE one line description
% RBFARDVARDISTPSI2COMPUTE one line description
% KERNKERNVARDISTPSI2COMPUTE description.
% LINARD2VARDISTPSI1GRADIENT description.
% LINARD2VARDISTPSI0GRADIENT description.
% VARGPLVMOPTIONS Return default options for VARGPLVM model.
% KERNVARDISTPSI2GRADIENT description.  
% KERNVARDISTPSI1COMPUTE description.  
% VARGPLVMGRADIENT Variational GP-LVM gradient wrapper.
% VARGPLVMLOGLIKELIHOOD Log-likelihood for a variational GP-LVM.
% VARGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% LINARDVARDISTPSI1GRADIENT description.
% LINARDVARDISTPSI1COMPUTE description.
% VARGPLVMOPTIMISE Optimise the VARGPLVM.
% BIASVARDISTPSI0GRADIENT one line description
% VARGPLVMPARAMINIT Initialize the variational GPLVM from the data
% RBFARD2VARDISTPSI1GRADIENT description.
% DEMBRENDANFGPLVM7 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 5 latent dimensions
% RBFARD2LINARD2VARDISTPSI2COMPUTE description
% VARGPLVMOBJECTIVEGRADIENT Wrapper function for VARGPLVM objective and gradient.
% RBFARDVARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI0COMPUTE Description
% DEMOIL100POINT Description
% VARGPLVMOBJECTIVE Wrapper function for variational GP-LVM objective.
% DEMBRENDANVARGPLVM2 Run variational GPLVM on Brendan face data.
% WHITEVARDISTPSI0COMPUTE one line description
% RBFARD2VARDISTPSI1COMPUTE description.
