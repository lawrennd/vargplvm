% VARGPLVM toolbox
% Version 0.14		12-Jul-2011
% Copyright (c) 2011, Neil D. Lawrence
% 
, Neil D. Lawrence
% KERNKERNVARDISTPSI2GRADIENT Description
% VARGPLVMTOOLBOXES Load in the relevant toolboxes for variational gplvm.
% KERNVARDISTPSI0GRADIENT description.  
% LINARD2BIASVARDISTPSI2COMPUTE one line description
% PREPROCESSVIDEO Transform video files of various types into 2-D matrices.
% VARGPLVMSEQDYNOBJECTIVE Wrapper function for objective of a group of points in latent space and the output locations..
% BIASVARDISTPSI1COMPUTE one line description
% RBFARD2VARDISTPSI0GRADIENT Description
% VARGPLVMRESTOREPRUNEDMODEL Restore a pruned var-GPLVM model.
% VARGPLVMOBJECTIVE Wrapper function for variational GP-LVM objective.
% VARGPLVMPARTEXPAND
% VARGPLVMPRUNEMODEL Prune a var-GPLVM model.
% VARGPLVMUPDATESTATS Update stats for VARGPLVM model.
% DEMHIGHDIMVARGPLVMTRAINED Perform tasks (predictions, sampling) for an already trained model on high dimensinoal video datasets.
% DEMUSPSVARGPLVM2 Demonstrate linear variational GPLVM (Bayesian PCA) on USPS data.
% DEMCMU35VARGPLVMRECONSTRUCTTAYLOR Reconstruct right leg and body of CMU 35.
% VARDISTEXTRACTPARAM Extract a parameter vector from a vardist structure.
% SKELPLAYDATA2 Play skel motion capture data for more than one dataset (for comparison).
% NIPS_DEMOS Reproduce all results and plots used for the NIPS 2011 paper.
% KERNVARDISTPSI0COMPUTE description.  
% RBFARDVARDISTPSI2COMPUTE one line description
% DEMOIL100VARGPLVMDYN1 Run variational GPLVM on 100 points from the oil data.
% RBFARD2BIASVARDISTPSI2COMPUTE description.
% VARGPTIMEDYNAMICSVARPRIORGRADIENTS This function does all the work for calculating the
% DEMSTICKVARGPLVMDYNMISSING1 Run variational GPLVM on stick man data with
% DEMHIGHDIMVARGPLVMLOADPRED Load predictions of the var. GPLVM made on high dimensional video datasets.
% DEMBRENDANVARGPLVMDYN1 Run variational GPLVM on Brendan face data.
% DEMBRENDANVARGPLVM2 Run variational GPLVM on Brendan face data.
% VARGPTIMEDYNAMICSVARPRIORBOUND Computes the term of the variational
% BIASVARDISTPSI1GRADIENT Compute gradient of bias variational PSI1.
% VARGPLVMCREATE Create a GPLVM model with inducing variables.
% LINARDVARDISTPSI1GRADIENT description.
% VARGPLVMPROBABILITYCOMPUTE description
% VARGPLVMOPTIONSDYN Fill in an options structure with default parameters
% SAVEMOVIESCRIPT A demonstration on the use of playMov.m for saving a
% VARGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% KERNKUUXUGRADIENT Description
% DEMFINANCE2 Demonstrate Variational GPLVM with dynamics on financial data for multivariate time series (i.e multiple univariate time series)
% DEMSWISSROLLVARGPLVM1 Run variational GPLVM on swiss roll data.
% WHITEVARDISTPSI2GRADIENT Compute gradient of white variational PSI2.
% MODELPRIORREPARAMGRADS Wrapper function for the gradients of the various types of the
% RBFARD2BIASVARDISTPSI2GRADIENT description.
% DEMOILVARGPLVM2 Run variational GPLVM on oil data.
% DEMCMU35VARGPLVMPLOTSSCALED Load results for the dyn. GPLVM on CMU35 data and produce plots
% VARGPTIMEDYNAMICSUPDATESTATS Supplementary update stats for when the model contains
% LINARD2BIASVARDISTPSI2GRADIENT description.
% VARGPLVMOPTIMISESEQDYN Optimise the positions of a group of latent
% RBFARDJITVARDISTPSI2COMPUTE one line description
% VARGPLVMSEQDYNLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% VARGPLVMLOGLIKELIHOOD Log-likelihood for a variational GP-LVM.
% BIASVARDISTPSI2GRADIENT Compute gradient of bias variational PSI2.
% VARGPLVMDYNAMICSUPDATEMODELTESTVAR return the original variational means and
% BIASVARDISTPSI0GRADIENT one line description
% BIASVARDISTPSI2COMPUTE one line description
% VARDISTCREATE description.
% VARGPLVMOPTIONS Return default options for VARGPLVM model.
% VARGPLVMREDUCEMODEL prunes out dimensions of the model.
% DEMCMU35GPLVMVARGPLVM3 Run variational GPLVM with dynamics on CMU35 data.
% VARGPLVMPARAMINIT Initialize the variational GPLVM from the data
% VARGPLVMPOINTLOGLIKELIHOOD Log-likelihood of one or more points for the GP-LVM.
% VARGPLVMREDUCEVIDMODEL Take a model computed on a video dataset and return a model which is computed on
% DEMROBOTWIRELESSVARGPLVMDYN1 Run variational GPLVM on robot wireless
% VARGPLVMEXTRACTPARAM Extract a parameter vector from a variational GP-LVM model.
% PLAYMOV Play a video file which is stored by rows in a 2-D matrix.
% VARGPLVMGRADIENT Variational GP-LVM gradient wrapper.
% VARGPLVMSEQDYNGRADIENT Wrapper function for gradient of a single point.
% VARGPTIMEDYNAMICSEXTRACTPARAM Extract parameters from the GP time dynamics model.
% RBFARD2VARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI1COMPUTE description.
% DEMHIGHDIMVARGPLVM3 This is the main script to run variational GPLVM on
% WHITEVARDISTPSI0COMPUTE one line description
% RBFARDVARDISTPSI2GRADIENT description.
% VARGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% RBFARDVARDISTPSI1COMPUTE one line description
% DEMOSNIPS
% RBFARDJITVARDISTPSI1GRADIENT description.
% KERNVARDISTPSI2GRADIENT description.  
% DEMOILVARGPLVM1 Run variational GPLVM on oil data.
% RBFARD2VARDISTPSI2COMPUTE one line description
% RBFARD2LINARD2VARDISTPSI2COMPUTE description
% BIASVARDISTPSI0COMPUTE one line description
% VARDISTEXPANDPARAM Expand a parameter vector into a vardist structure.
% VARGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% KERNVARDISTPSI2COMPUTE description.  
% RBFARDJITVARDISTPSI2GRADIENT description.
% WHITEVARDISTPSI0GRADIENT one line description
% VARGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% VARGPLVMPOSTERIORVAR variances of the posterior at points given by X.
% WHITEVARDISTPSI1COMPUTE one line description
% LINARD2VARDISTPSI0COMPUTE Description
% VARGPTIMEDYNAMICSPRIORREPARAMGRADS Returns the gradients of the various types of the
% VARGPLVMDYNAMICSUPDATESTATS wrapper function which according to the type
% MODELPRIORKERNGRAD
% VARGPLVMLOGLIKEGRADIENTS Compute the gradients for the variational GPLVM.
% VARGPTIMEDYNAMICSCREATE Create the time dynamics variational model.
% RBFARD2LINARD2VARDISTPSI2GRADIENT description
% KERNKERNVARDISTTEST Description
% ADDDEFAULTVARGPTIMEDYNAMICS
% LINARD2VARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI2COMPUTE description.
% RBFARD2VARDISTPSI1COMPUTE description.
% DEMUSPSVARGPLVM1 Demonstrate variational GPLVM on USPS data. 
% KERNKERNVARDISTPSI2COMPUTE description.
% VARGPTIMEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP time dynamics.
% MODELVARPRIORBOUND Wrapper function for the various types of the
% VARGPLVMINITDYNAMICS Initialize the dynamics of a var-GPLVM model.
% VARGPLVMSEQDYNLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% RBFARDJITVARDISTPSI1COMPUTE description.
% LINARD2VARDISTPSI1GRADIENT description.
% RBFARD2VARDISTPSI1GRADIENT description.
% RBFARDJITVARDISTPSI0GRADIENT Description
% VARGPLVMTAYLORANGLEERRORS Helper function for computing angle errors for CMU 35 data using 
% VARGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% DEMOSDYNAMICS Reproduce all results and plots used for the VGPDS ARXIV 2011 paper.
% DEMCMU35VARGPLVMLOADCHANNELS Given a dataset load the skeleton channels
% KERNVARDISTTEST description.
% LINARDVARDISTPSI1COMPUTE description.
% LINARD2VARDISTPSI0GRADIENT description.
% RBFARD2VARDISTPSI0COMPUTE description.
% DEMBRENDANVARGPLVM1 Run variational GPLVM on Brendan face data.
% KERNVARDISTPSI1GRADIENT description.  
% VARGPLVMREDUCEVIDEO Receives a video and reduces its resolution by factor1 (lines) and factor2).
% VARGPLVMADDDYNAMICS Add a dynamics structure to the model.
% DEMBRENDANVARGPLVM3 Run variational GPLVM on Brendan face data.
% WHITEVARDISTPSI1GRADIENT Compute gradient of white variational Psi1.
% DEMBRENDANVARGPLVM4 Run variational GPLVM on Brendan face data with missing (test) data.
% VARGPLVMPREDICTPOINT Predict the postions of a number of latent points.
% KERNVARDISTPSI1COMPUTE description.  
% VARGPLVMOPTIMISEPOINT Optimise the postion of one or more latent points.
%VARGPTIMEDYNAMICSSAMPLE
% VARGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of some points of the GP-LVM.
% WHITEVARDISTPSI2COMPUTE one line description
% VARGPLVMOPTIMISE Optimise the VARGPLVM.
% VARGPLVMOBJECTIVEGRADIENT Wrapper function for VARGPLVM objective and gradient.
% DEMCMU35VARGPLVMANIMATE Load results for the dyn. GPLVM on CMU35 data and
% RBFARDJITVARDISTPSI0COMPUTE description.
