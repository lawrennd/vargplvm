function k0 = rbfardjitVardistPsi0Compute(rbfardKern, vardist)

% RBFARDJITVARDISTPSI0COMPUTE description.
%
%	Description:
%	k0 = rbfardjitVardistPsi0Compute(rbfardKern, vardist)
%% 	rbfardjitVardistPsi0Compute.m SVN version 1480
% 	last update 2011-07-04T22:42:09.277918Z
  
% variational means


% dont intlude the jitter term (it only for the inducing matrix K_uu)

k0 = vardist.numData*rbfardKern.variance; 
