function [params, names] = vargplvmExtractParam(model)

% VARGPLVMEXTRACTPARAM Extract a parameter vector from a variational GP-LVM model.
%
%	Description:
%
%	PARAMS = VARGPLVMEXTRACTPARAM(MODEL) extracts a parameter vector
%	from a given VARGPLVM structure.
%	 Returns:
%	  PARAMS - the parameter vector extracted from the model.
%	 Arguments:
%	  MODEL - the model from which parameters are to be extracted.
%	DESC does the same as above, but also returns parameter names.
%	ARG model : the model structure containing the information about
%	the model.
%	RETURN params : a vector of parameters from the model.
%	RETURN names : cell array of parameter names.
%	
%	
%
%	See also
%	VARGPLVMCREATE, VARGPLVMEXPANDPARAM, MODELEXTRACTPARAM


%	Copyright (c) 2009 Michalis K. Titsias and Neil D. Lawrence
% 	vargplvmExtractParam.m SVN version 583
% 	last update 2009-11-08T13:07:34.000000Z

if nargout > 1
  returnNames = true;
else
  returnNames = false;
end 

% Kernel parameters  
if returnNames
  [kernParams, kernParamNames] = kernExtractParam(model.kern); 
  for i = 1:length(kernParamNames)
    kernParamNames{i} = ['Kernel, ' kernParamNames{i}];
  end
  names = {kernParamNames{:}};
else
  kernParams = kernExtractParam(model.kern);
end
params = kernParams;


% beta in the likelihood 
if model.optimiseBeta
   fhandle = str2func([model.betaTransform 'Transform']);
   betaParam = fhandle(model.beta, 'xtoa');
   params = [params betaParam(:)'];
   if returnNames
     for i = 1:length(betaParam)
       betaParamNames{i} = ['Beta ' num2str(i)];
     end
     names = {names{:}, betaParamNames{:}};
   end
end

% Inducing inputs 
if ~model.fixInducing
    params =  [model.X_u(:)' params];
    if returnNames 
      for i = 1:size(model.X_u, 1)
      for j = 1:size(model.X_u, 2)
          X_uNames{i, j} = ['X_u(' num2str(i) ', ' num2str(j) ')'];
      end
      end
      names = {X_uNames{:}, names{:}};
    end
end

% Variational parameters 
if returnNames
  %[varParams, varNames] = vardistExtractParam(model.vardist);
  [varParams, varNames] = modelExtractParam(model.vardist);
  params = [varParams params];
  names = {varNames{:}, names{:}}; 
else
  %varParams = vardistExtractParam(model.vardist);
  varParams = modelExtractParam(model.vardist);
  params = [varParams params];
end

