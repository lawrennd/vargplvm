function f = vargplvmPointObjective(x, model, y, indexPresent)

% VARGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
%
%	Description:
%
%	F = VARGPLVMPOINTOBJECTIVE(X, MODEL, Y) provides a wrapper function
%	for the negative log probability of a given data point under the
%	posterior distribution of the Gaussian process induced by the
%	training data.
%	 Returns:
%	  F - the negative of the log probability of the given data point
%	   under the posterior distribution induced by the training data.
%	 Arguments:
%	  X - location in input space for the point.
%	  MODEL - the model structure for which the negative log probability
%	   of the given data under the posterior is to be computed.
%	  Y - the location in data space for the point.
%	
%
%	See also
%	VARGPLVMCREATE, VARGPLVMPOINTLOGLIKELIHOOD, VARGPLVMOPTIMISEPOINT


%	Copyright (c) 2009 Michalis K. Titsias and Neil D. Lawrence
% 	vargplvmPointObjective.m SVN version 583
% 	last update 2009-11-08T13:07:35.000000Z

vardistx = model.vardistx;
vardistx = vardistExpandParam(vardistx, x);
f = - vargplvmPointLogLikelihood(model, vardistx, y, indexPresent);
