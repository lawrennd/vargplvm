function model = vargplvmOptimise(model, display, iters);

% VARGPLVMOPTIMISE Optimise the VARGPLVM.
%
%	Description:
%
%	MODEL = VARGPLVMOPTIMISE(MODEL, DISPLAY, ITERS) takes a given GP-LVM
%	model structure and optimises with respect to parameters and latent
%	positions.
%	 Returns:
%	  MODEL - the optimised model.
%	 Arguments:
%	  MODEL - the model to be optimised.
%	  DISPLAY - flag dictating whether or not to display optimisation
%	   progress (set to greater than zero) (default value 1).
%	  ITERS - number of iterations to run the optimiser for (default
%	   value 2000).
%	vargplvmLogLikeGradients, vargplvmObjective, vargplvmGradient
%	
%	
%
%	See also
%	VARGPLVMCREATE, VARGPLVMLOGLIKELIHOOD, 


%	Copyright (c) 2009 Michalis K. Titsias
%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	vargplvmOptimise.m SVN version 583
% 	last update 2009-11-08T13:07:35.000000Z


if nargin < 3
  iters = 2000;
  if nargin < 2
    display = 1;
  end
end


params = vargplvmExtractParam(model);

options = optOptions;
options(2) = 0.1*options(2); 
options(3) = 0.1*options(3);

if display
  options(1) = 1;
  if length(params) <= 100
    options(9) = 1;
  end
end
options(14) = iters;

if isfield(model, 'optimiser')
  optim = str2func(model.optimiser);
else
  optim = str2func('scg');
end

if strcmp(func2str(optim), 'optimiMinimize')
  % Carl Rasmussen's minimize function 
  params = optim('vargplvmObjectiveGradient', params, options, model);
else
  % NETLAB style optimization.
  params = optim('vargplvmObjective', params,  options, ...
                 'vargplvmGradient', model);
end

model = vargplvmExpandParam(model, params);
