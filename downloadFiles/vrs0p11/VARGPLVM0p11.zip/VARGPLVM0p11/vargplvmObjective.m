function f = vargplvmObjective(params, model)

% VARGPLVMOBJECTIVE Wrapper function for variational GP-LVM objective.
%
%	Description:
%
%	F = VARGPLVMOBJECTIVE(PARAMS, MODEL) provides a wrapper function for
%	the variational GP-LVM, it takes the negative of the log likelihood,
%	feeding the parameters correctly to the model.
%	 Returns:
%	  F - the negative of the log likelihood of the model.
%	 Arguments:
%	  PARAMS - the parameters of the variational GP-LVM model.
%	  MODEL - the model structure in which the parameters are to be
%	   placed.
%	
%	
%
%	See also
%	VARGPLVMCREATE, VARGPLVMLOGLIKELIHOOD, VARGPLVMEXPANDPARAM


%	Copyright (c) 2009 Michalis K. Titsias
%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	vargplvmObjective.m SVN version 583
% 	last update 2009-11-08T13:07:35.000000Z

model = vargplvmExpandParam(model, params);
f = - vargplvmLogLikelihood(model);
