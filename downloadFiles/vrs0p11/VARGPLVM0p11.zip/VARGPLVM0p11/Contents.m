% VARGPLVM toolbox
% Version 0.11		17-Nov-2010
% Copyright (c) 2010, Neil D. Lawrence
% 
, Neil D. Lawrence
% BIASVARDISTPSI2COMPUTE one line description
% WHITEVARDISTPSI0COMPUTE one line description
% DEMBRENDANFGPLVM8 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 10 latent dimensions
% DEMOIL100POINT Description
% RBFARD2VARDISTPSI2COMPUTE one line description
% VARGPLVMPARAMINIT Initialize the variational GPLVM from the data
% KERNVARDISTTEST description.
% VARDISTCREATE description.
% KERNVARDISTPSI1GRADIENT description.  
% DEMBRENDANFGPLVM7 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 5 latent dimensions
% VARGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% VARGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% KERNKERNVARDISTPSI2GRADIENT Description
% RBFARD2VARDISTPSI1COMPUTE description.
% DEMBRENDANVARGPLVM3 Run variational GPLVM on Brendan face data.
% VARGPLVMTOOLBOXES Load in the relevant toolboxes for variational gplvm.
% LINARDVARDISTPSI1GRADIENT description.
% DEMUSPSVARGPLVM1 Demonstrate variational GPLVM on USPS data. 
% VARGPLVMUPDATESTATS Update stats of VARGPLVM model.
% KERNVARDISTPSI2COMPUTE description.  
% DEMBRENDANVARGPLVM2 Run variational GPLVM on Brendan face data.
% KERNVARDISTPSI0GRADIENT description.  
% VARGPLVMPOSTERIORVAR variances of the posterior at points given by X.
% LINARDVARDISTPSI1COMPUTE description.
% RBFARD2VARDISTPSI0GRADIENT Description
% BIASVARDISTPSI1GRADIENT Compute gradient of bias variational PSI1.
% KERNVARDISTPSI0COMPUTE description.  
% RBFARD2LINARD2VARDISTPSI2GRADIENT description
% VARGPLVMGRADIENT Variational GP-LVM gradient wrapper.
% WHITEVARDISTPSI1GRADIENT Compute gradient of white variational Psi1.
% VARGPLVMREDUCEMODEL prunes out dimensions of the model.
% VARGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% BIASVARDISTPSI0COMPUTE one line description
% RBFARDVARDISTPSI2GRADIENT description.
% KERNKUUXUGRADIENT Description
% BIASVARDISTPSI2GRADIENT Compute gradient of bias variational PSI2.
% WHITEVARDISTPSI2COMPUTE one line description
% DEMBRENDANVARGPLVM1 Run variational GPLVM on Brendan face data.
% RBFARD2VARDISTPSI1GRADIENT description.
% WHITEVARDISTPSI0GRADIENT one line description
% LINARD2VARDISTPSI2GRADIENT description.
% VARDISTEXTRACTPARAM Extract a parameter vector from a vardist structure.
% DEMOIL100VARGPLVM1 Run variational GPLVM on 100 points from the oil data.
% RBFARD2LINARD2VARDISTPSI2COMPUTE description
% KERNVARDISTPSI1COMPUTE description.  
% VARGPLVMEXTRACTPARAM Extract a parameter vector from a variational GP-LVM model.
% VARGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% WHITEVARDISTPSI2GRADIENT Compute gradient of white variational PSI2.
% VARGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% VARGPLVMPROBABILITYCOMPUTE description
% DEMUSPSVARGPLVM2 Demonstrate linear variational GPLVM (Bayesian PCA) on USPS data.
% BIASVARDISTPSI0GRADIENT one line description
% LINARD2BIASVARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI0COMPUTE Description
% VARGPLVMLOGLIKEGRADIENTS Compute the gradients for the variational GPLVM.
% VARGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% LINARD2VARDISTPSI1GRADIENT description.
% RBFARD2VARDISTPSI0COMPUTE description.
% RBFARD2BIASVARDISTPSI2GRADIENT description.
% VARGPLVMCREATE Create a GPLVM model with inducing variables.
% DEMOILVARGPLVM2 Run variational GPLVM on oil data.
% RBFARD2BIASVARDISTPSI2COMPUTE description.
% LINARD2VARDISTPSI2COMPUTE description.
% VARGPLVMOBJECTIVE Wrapper function for variational GP-LVM objective.
% DEMBRENDANFGPLVM9 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 30 latent dimensions
% RBFARDVARDISTPSI1COMPUTE one line description
% DEMOVARGPLVM1 Description ...
% KERNKERNVARDISTTEST Description
% RBFARD2VARDISTPSI2GRADIENT description.
% LINARD2VARDISTPSI1COMPUTE description.
% DEMROBOTWIRELESSVARGPLVM1 Run variational GPLVM on robot wireless data.
% VARDISTEXPANDPARAM Expand a parameter vector into a vardist structure.
% VARGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% DEMBRENDANFGPLVM6 Reconstruction of partial observed test data in Brendan faces using sparse GP-LVM (with dtcvar) and 2 latent dimensions
% KERNVARDISTPSI2GRADIENT description.  
% LINARD2BIASVARDISTPSI2COMPUTE one line description
% RBFARDVARDISTPSI2COMPUTE one line description
% VARGPLVMOPTIONS Return default options for VARGPLVM model.
% KERNKERNVARDISTPSI2COMPUTE description.
% WHITEVARDISTPSI1COMPUTE one line description
% LINARD2VARDISTPSI0GRADIENT description.
% VARGPLVMOBJECTIVEGRADIENT Wrapper function for VARGPLVM objective and gradient.
% DEMSWISSROLLVARGPLVM1 Run variational GPLVM on swiss roll data.
% VARGPLVMLOGLIKELIHOOD Log-likelihood for a variational GP-LVM.
% VARGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% DEMOILVARGPLVM1 Run variational GPLVM on oil data.
% VARGPLVMOPTIMISE Optimise the VARGPLVM.
% BIASVARDISTPSI1COMPUTE one line description
